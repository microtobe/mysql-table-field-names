mysql-field-names
=================

mysql database field's name list.

Table name list is in tables file.<br>
Field name list is in fields file.


